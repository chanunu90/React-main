import './App.css';
import Footer from './components/commonComponents/Footer';


function App() {

  return (
    <div className="App">
      <Footer></Footer>
    </div>
  );
}

export default App;
 