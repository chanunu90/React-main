import main from "../../public/main_slider05.jpg"

const TopCenterBoard = () => {


  
    return ( 
    <div>
        <div className='bg-purple-100 rounded-2xl m-10 mb-2 mt-2 flex h-[500px]'>
            <img className="w-full object-cover" src={main}></img>
        </div>
    </div>
    );
}
 
export default TopCenterBoard;